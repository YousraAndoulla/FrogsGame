package frogsgameb;

import java.awt.Toolkit;
import java.awt.event.WindowEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import jdk.javadoc.internal.doclets.formats.html.markup.Text;
//import java.beans.Statement;



public class Game extends javax.swing.JFrame {
//Game user;
Game win;
String txtname;
Game loss;
 int w,l;
Text scorewin;
    public Game() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        ButtonJumpOver = new frogsgameb.MyButton();
        buttonJump = new frogsgameb.MyButton();
        ButtonDone = new frogsgameb.MyButton();
        position7 = new javax.swing.JButton();
        position1 = new javax.swing.JButton();
        position2 = new javax.swing.JButton();
        position3 = new javax.swing.JButton();
        position6 = new javax.swing.JButton();
        position4 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        position5 = new javax.swing.JButton();
        user = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Frogs Game");
        setBackground(new java.awt.Color(255, 255, 153));

        jPanel1.setBackground(new java.awt.Color(255, 255, 153));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 204, 51), 3));
        jPanel1.setMaximumSize(new java.awt.Dimension(900, 500));
        jPanel1.setMinimumSize(new java.awt.Dimension(900, 500));
        jPanel1.setPreferredSize(new java.awt.Dimension(900, 500));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ButtonJumpOver.setForeground(new java.awt.Color(255, 255, 153));
        ButtonJumpOver.setText("Jum Over");
        ButtonJumpOver.setAlignmentX(1.0F);
        ButtonJumpOver.setColor(new java.awt.Color(184, 190, 82));
        ButtonJumpOver.setColorClick(new java.awt.Color(164, 180, 4));
        ButtonJumpOver.setColorOver(new java.awt.Color(184, 190, 82));
        ButtonJumpOver.setFont(new java.awt.Font("Berlin Sans FB Demi", 0, 30)); // NOI18N
        ButtonJumpOver.setRadius(50);
        ButtonJumpOver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonJumpOverActionPerformed(evt);
            }
        });
        jPanel1.add(ButtonJumpOver, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 320, -1, 50));

        buttonJump.setForeground(new java.awt.Color(255, 255, 153));
        buttonJump.setText("Jump");
        buttonJump.setAlignmentX(1.0F);
        buttonJump.setColor(new java.awt.Color(184, 190, 82));
        buttonJump.setColorClick(new java.awt.Color(164, 180, 4));
        buttonJump.setColorOver(new java.awt.Color(184, 190, 82));
        buttonJump.setFont(new java.awt.Font("Berlin Sans FB Demi", 0, 30)); // NOI18N
        buttonJump.setRadius(50);
        buttonJump.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonJumpActionPerformed(evt);
            }
        });
        jPanel1.add(buttonJump, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 320, 160, 50));

        ButtonDone.setForeground(new java.awt.Color(255, 255, 153));
        ButtonDone.setText("Done");
        ButtonDone.setAlignmentX(1.0F);
        ButtonDone.setColor(new java.awt.Color(164, 180, 4));
        ButtonDone.setColorClick(new java.awt.Color(255, 153, 0));
        ButtonDone.setColorOver(new java.awt.Color(164, 180, 4));
        ButtonDone.setFont(new java.awt.Font("Berlin Sans FB Demi", 0, 30)); // NOI18N
        ButtonDone.setRadius(50);
        ButtonDone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonDoneActionPerformed(evt);
            }
        });
        jPanel1.add(ButtonDone, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 420, -1, 50));

        position7.setBackground(new java.awt.Color(255, 255, 153));
        position7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/brownFrog.png"))); // NOI18N
        position7.setBorder(null);
        position7.setOpaque(true);
        position7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                position7ActionPerformed(evt);
            }
        });
        jPanel1.add(position7, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 170, 70, 70));

        position1.setBackground(new java.awt.Color(255, 255, 153));
        position1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/greenFrog.png"))); // NOI18N
        position1.setBorder(null);
        position1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                position1ActionPerformed(evt);
            }
        });
        jPanel1.add(position1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 170, 70, 70));

        position2.setBackground(new java.awt.Color(255, 255, 153));
        position2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/greenFrog.png"))); // NOI18N
        position2.setBorder(null);
        position2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                position2ActionPerformed(evt);
            }
        });
        jPanel1.add(position2, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 170, 70, 70));

        position3.setBackground(new java.awt.Color(255, 255, 153));
        position3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/greenFrog.png"))); // NOI18N
        position3.setBorder(null);
        position3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                position3ActionPerformed(evt);
            }
        });
        jPanel1.add(position3, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 170, 70, 70));

        position6.setBackground(new java.awt.Color(255, 255, 153));
        position6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/brownFrog.png"))); // NOI18N
        position6.setBorder(null);
        position6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                position6ActionPerformed(evt);
            }
        });
        jPanel1.add(position6, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 170, 70, 70));

        position4.setBackground(new java.awt.Color(255, 255, 153));
        position4.setBorder(null);
        position4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                position4ActionPerformed(evt);
            }
        });
        jPanel1.add(position4, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 170, 70, 70));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/rock.png"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 240, 120, 50));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/rock.png"))); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 240, 120, 50));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/rock.png"))); // NOI18N
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 240, 110, 50));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/rock.png"))); // NOI18N
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 240, 120, 50));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/rock.png"))); // NOI18N
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 240, 110, 50));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/rock.png"))); // NOI18N
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 240, 110, 50));

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/rock.png"))); // NOI18N
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 240, 120, 50));

        position5.setBackground(new java.awt.Color(255, 255, 153));
        position5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/brownFrog.png"))); // NOI18N
        position5.setBorder(null);
        position5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                position5ActionPerformed(evt);
            }
        });
        jPanel1.add(position5, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 170, 70, 70));

        user.setBackground(new java.awt.Color(255, 204, 102));
        user.setFont(new java.awt.Font("Segoe UI", 3, 36)); // NOI18N
        user.setForeground(new java.awt.Color(255, 255, 255));
        user.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        user.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        user.setOpaque(true);
        jPanel1.add(user, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 20, 220, 50));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    
    private void ButtonDoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonDoneActionPerformed
        if(position1.getIcon().toString().compareTo(brownfrog)==0 
        && position2.getIcon().toString().compareTo(brownfrog)==0
        && position3.getIcon().toString().compareTo(brownfrog)==0
        && position5.getIcon().toString().compareTo(greenfrog)==0
        && position6.getIcon().toString().compareTo(greenfrog)==0
        && position7.getIcon().toString().compareTo(greenfrog)==0){
        
                close();
                
                Win win=new Win();
                win.setVisible(true);
                String user=txtname;
                win.setLocationRelativeTo(null);
                win.setUsername(user);
                win.txtname=user;
                
              
                   try {
     
               String query="SELECT win  FROM gamefrog.players WHERE name = '"+getUsername()+"';";
              java.sql.Statement ps= MyConnection.getConnection().createStatement();
             ResultSet rs=ps.executeQuery(query);
            int w=0;
              if(rs.next()){
               w=Integer.parseInt(rs.getString(1));
               w++;
              
             query="update players set win='"+w+"'where name = '"+getUsername()+"';";
              ps.executeUpdate(query);
          
                
                int scorewin=w;
                win.setLocationRelativeTo(null);
               String w1="win : "+String.valueOf(w);
               win.setWin(w1);
             
               win.w=scorewin;
                this.setVisible(false);
              } 
           } catch (SQLException ex) {
                Logger.getLogger(Game.class.getName()).log(Level.SEVERE, null, ex);
            }
         
                   
                try{
               String query="SELECT loss FROM gamefrog.players WHERE name = '"+getUsername()+"';";
              java.sql.Statement ps= MyConnection.getConnection().createStatement();
             ResultSet rs=ps.executeQuery(query);
            int l=0;
              if(rs.next()){
               l=Integer.parseInt(rs.getString(1));
             
              
                
                int scoreloss=l;
                win.setLocationRelativeTo(null);
               String l1="loss : "+String.valueOf(l);
               win.setLoss(l1);
             
               win.l=scoreloss;
                this.setVisible(false);
              } 
           } catch (SQLException ex) {
                Logger.getLogger(Game.class.getName()).log(Level.SEVERE, null, ex);
            }
            
                   
         
        }else{
            close();
          
            
          Loss loss=new Loss();
         loss.setVisible(true);
         String user1=txtname;
         loss.setLocationRelativeTo(null);
         loss.setUsername(user1);
        loss.txtname=user1;
        this.setVisible(false);
        
        
        
        
                   try {
     
               String query="SELECT loss FROM gamefrog.players WHERE name = '"+getUsername()+"';";
              java.sql.Statement ps= MyConnection.getConnection().createStatement();
             ResultSet rs=ps.executeQuery(query);
            int l=0;
              if(rs.next()){
               l=Integer.parseInt(rs.getString(1));
               l++;
              
             query="update players set loss='"+l+"'where name = '"+getUsername()+"';";
              ps.executeUpdate(query);
          
                
                int scoreloss=l;
                loss.setLocationRelativeTo(null);
               String l1="loss : "+String.valueOf(l);
               loss.setLoss(l1);
             
               loss.l=scoreloss;
                this.setVisible(false);
              } 
           } catch (SQLException ex) {
                Logger.getLogger(Game.class.getName()).log(Level.SEVERE, null, ex);
            }
                   
              try {
     
               String query="SELECT win FROM gamefrog.players WHERE name = '"+getUsername()+"';";
              java.sql.Statement ps= MyConnection.getConnection().createStatement();
             ResultSet rs=ps.executeQuery(query);
            int w=0;
              if(rs.next()){
               w=Integer.parseInt(rs.getString(1));
              
          
                
                int scorewin=w;
                loss.setLocationRelativeTo(null);
               String w1="win : "+String.valueOf(w);
               loss.setWin(w1);
             
               loss.w=scorewin;
                this.setVisible(false);
              } 
           } catch (SQLException ex) {
                Logger.getLogger(Game.class.getName()).log(Level.SEVERE, null, ex);
            } 
                   
                   
        }
        
    
        
    }//GEN-LAST:event_ButtonDoneActionPerformed

    private void buttonJumpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonJumpActionPerformed
        currentButton.setIcon(null);
        nextButton.setIcon(currentIcon);
    }//GEN-LAST:event_buttonJumpActionPerformed
    
    private Icon currentIcon;
    private JButton currentButton,nextButton,nextNextButton;
    private final String greenfrog = new ImageIcon("file:/C:/Users/youra%20andoulla/Documents/NetBeansProjects/FrogsGameB/build/classes/Image/greenFrog.png").toString();
    private final String brownfrog = new ImageIcon("file:/C:/Users/youra%20andoulla/Documents/NetBeansProjects/FrogsGameB/build/classes/Image/brownFrog.png").toString();
    
    private void ButtonJumpOverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonJumpOverActionPerformed
        currentButton.setIcon(null);
        nextNextButton.setIcon(currentIcon);
    }//GEN-LAST:event_ButtonJumpOverActionPerformed

    private void position2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_position2ActionPerformed
        currentIcon = position2.getIcon();
        currentButton = position2;
        if(currentIcon.toString().compareTo(greenfrog) == 0){
            nextButton = position3;
            nextNextButton = position4;
        }else{
            nextButton=position1;
        }
    }//GEN-LAST:event_position2ActionPerformed

    private void position1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_position1ActionPerformed
        currentIcon = position1.getIcon();
        currentButton = position1;
        if(currentIcon.toString().compareTo(greenfrog)== 0){
            nextButton = position2;
            nextNextButton=position3;
        }
    }//GEN-LAST:event_position1ActionPerformed

    private void position4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_position4ActionPerformed
        currentIcon = position4.getIcon();
        currentButton = position4;
        if(currentIcon.toString().compareTo(greenfrog) == 0){
            nextButton=position5;
            nextNextButton=position6;
        }else{
            nextButton = position3;
            nextNextButton = position2;
        }
    }//GEN-LAST:event_position4ActionPerformed

    private void position7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_position7ActionPerformed
        currentIcon = position7.getIcon();
        currentButton = position7;
        System.out.println(currentIcon.toString());
        if(currentIcon.toString().compareTo(brownfrog)== 0){
            nextButton=position6;
            nextNextButton=position5;
        }
    }//GEN-LAST:event_position7ActionPerformed

    private void position3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_position3ActionPerformed
        currentIcon = position3.getIcon();
        currentButton = position3;
        if(currentIcon.toString().compareTo(greenfrog)== 0){
            nextButton=position4;
            nextNextButton=position5;     
        }else{
            nextButton = position2;
            nextNextButton = position1; 
        }
    }//GEN-LAST:event_position3ActionPerformed

    private void position6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_position6ActionPerformed
        currentIcon = position6.getIcon();
        currentButton = position6;
        if(currentIcon.toString().compareTo(greenfrog) == 0){
            nextButton=position7;
        }else{
            nextButton = position5;
            nextNextButton = position4;
        }
    }//GEN-LAST:event_position6ActionPerformed

    private void position5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_position5ActionPerformed
        currentIcon = position5.getIcon();
        currentButton = position5;
        if(currentIcon.toString().compareTo(greenfrog) == 0){
            nextButton=position6;
            nextNextButton = position7;
        }else{
            nextButton = position4;
            nextNextButton = position3;
        }
    }//GEN-LAST:event_position5ActionPerformed

    public void setUsername(String name){
        this.user.setText(name);
    }
    public String getUsername(){
        return this.user.getText();
    }
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Game.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Game.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Game.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Game.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Game().setVisible(true);
            }
        });
    }
     
    public void close() {
        WindowEvent closeWindow = new WindowEvent(this,WindowEvent.WINDOW_CLOSING);
        Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(closeWindow);
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    public frogsgameb.MyButton ButtonDone;
    private frogsgameb.MyButton ButtonJumpOver;
    private frogsgameb.MyButton buttonJump;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton position1;
    private javax.swing.JButton position2;
    private javax.swing.JButton position3;
    private javax.swing.JButton position4;
    private javax.swing.JButton position5;
    private javax.swing.JButton position6;
    private javax.swing.JButton position7;
    public javax.swing.JLabel user;
    // End of variables declaration//GEN-END:variables

  

}
